package com.safeanchor;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/**
 * Bảng màu: lưới màu (trái -> phải = tông màu, trên -> dưới = từ nhạt đến đậm) + hàng màu nhạt có sẵn.
 * Dùng CHUỘT PHẢI để kéo tới màu và click chọn (chuột trái cũng được). Bên dưới còn 3 thanh R/G/B để tinh chỉnh.
 */
public class ColorScreen extends MenuScreen {
    final int[] rgb = new int[3];
    final IntConsumer set;
    boolean dragPal;
    int markX = -1, markY = -1;
    static final int PW = 220, PH = 64, PRE = 12;
    static final int[] PASTEL = {0xFFB3D1, 0xFFD1DC, 0xFFDAC1, 0xFFF1B8, 0xE2F0CB, 0xB5EAD7, 0xC7F0FF,
            0xBFE3FF, 0xC7CEEA, 0xE0C3FC, 0xFFFFFF, 0xCCCCCC, 0x888888, 0x000000};

    public ColorScreen(String title, Screen parent, IntSupplier get, IntConsumer set) {
        super("Chọn màu: " + title, parent, new java.util.ArrayList<>());
        this.set = set;
        int cur = get.getAsInt();
        rgb[0] = (cur >> 16) & 255; rgb[1] = (cur >> 8) & 255; rgb[2] = cur & 255;
        String[] n = {"Đỏ (R)", "Xanh lá (G)", "Xanh dương (B)"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            makers.add(Pages.slider(n[i], 0, 255, true, () -> rgb[k], v -> { rgb[k] = (int) v; set.accept(cur()); }));
        }
    }

    int cur() { return (rgb[0] << 16) | (rgb[1] << 8) | rgb[2]; }
    int palX() { return width / 2 - PW / 2; }
    int palY() { return 60; }
    @Override int top() { return palY() + PH + 3 + PRE + 16; }

    /** hx: 0..1 tông màu; sy: 0..1 từ trên (nhạt) xuống dưới (đậm). */
    static int shade(double hx, double sy) {
        float s, b;
        if (sy < 0.5) { s = 0.12f + (float) (sy * 2) * 0.88f; b = 1f; }
        else { s = 1f; b = 1f - (float) ((sy - 0.5) * 2) * 0.85f; }
        return java.awt.Color.HSBtoRGB((float) hx, s, b) & 0xFFFFFF;
    }

    boolean inPal(double x, double y) {
        return x >= palX() && x <= palX() + PW && y >= palY() && y <= palY() + PH + 3 + PRE;
    }

    void apply(int c) {
        rgb[0] = (c >> 16) & 255; rgb[1] = (c >> 8) & 255; rgb[2] = c & 255;
        set.accept(c & 0xFFFFFF);
        double keep = scroll;
        init();                  // dựng lại 3 thanh trượt theo màu mới
        scroll = keep; layout();
    }

    void pick(double x, double y) {
        int px = palX(), py = palY();
        if (y <= py + PH) {
            double hx = Math.max(0, Math.min(0.9999, (x - px) / PW));
            double sy = Math.max(0, Math.min(1, (y - py) / (double) (PH - 1)));
            markX = (int) Math.max(px, Math.min(px + PW - 1, x));
            markY = (int) Math.max(py, Math.min(py + PH - 1, y));
            apply(shade(hx, sy));
        } else if (y >= py + PH + 3) {
            int i = (int) ((x - px) / ((double) PW / PASTEL.length));
            i = Math.max(0, Math.min(PASTEL.length - 1, i));
            markX = -1;
            apply(PASTEL[i]);
        }
    }

    @Override public boolean mouseClicked(double x, double y, int b) {
        if ((b == 0 || b == 1) && inPal(x, y)) { dragPal = true; pick(x, y); return true; }   // chuột phải (1) hoặc trái (0)
        return super.mouseClicked(x, y, b);
    }
    @Override public boolean mouseDragged(double x, double y, int b, double dx, double dy) {
        if (dragPal) { pick(x, y); return true; }
        return super.mouseDragged(x, y, b, dx, dy);
    }
    @Override public boolean mouseReleased(double x, double y, int b) {
        if (dragPal) { dragPal = false; return true; }
        return super.mouseReleased(x, y, b);
    }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        super.render(ctx, mx, my, d);
        int px = palX(), py = palY();
        ctx.fill(px - 1, py - 1, px + PW + 1, py + PH + 1, 0xFF000000);
        for (int cx = 0; cx < PW; cx += 4) for (int cy = 0; cy < PH; cy += 4)
            ctx.fill(px + cx, py + cy, px + Math.min(PW, cx + 4), py + Math.min(PH, cy + 4), 0xFF000000 | shade((cx + 2) / (double) PW, (cy + 2) / (double) PH));
        int ry = py + PH + 3;
        for (int i = 0; i < PASTEL.length; i++) {
            int x0 = px + (int) Math.round(i * (double) PW / PASTEL.length), x1 = px + (int) Math.round((i + 1) * (double) PW / PASTEL.length);
            ctx.fill(x0, ry, x1, ry + PRE, 0xFF000000 | PASTEL[i]);
        }
        if (markX >= 0) {
            ctx.fill(markX - 3, markY - 3, markX + 4, markY - 2, 0xFFFFFFFF);
            ctx.fill(markX - 3, markY + 3, markX + 4, markY + 4, 0xFFFFFFFF);
            ctx.fill(markX - 3, markY - 3, markX - 2, markY + 4, 0xFFFFFFFF);
            ctx.fill(markX + 3, markY - 3, markX + 4, markY + 4, 0xFFFFFFFF);
        }
        ctx.fill(width / 2 - 110, 46, width / 2 + 110, 54, 0xFF000000 | cur());
        ctx.drawCenteredTextWithShadow(textRenderer, "Chuột phải: kéo / click vào bảng để chọn màu", width / 2, py + PH + PRE + 6, 0xFF9090A0);
    }
}
