package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** HUD thông tin: FPS, ping, RAM, tọa độ+hướng, keystrokes+CPS, hiệu ứng thuốc, giáp, combo, danh sách module bật. */
public class Hud2 {
    static int col(Config c, double off) { return 0xFF000000 | (c.chroma ? Util.chroma(off) : c.hudColor); }

    public static void render(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance(); Config c = Config.I;
        if (!c.enabled || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        int W = ctx.getScaledWindowWidth(), H = ctx.getScaledWindowHeight();
        List<String> lines = new ArrayList<>();
        if (c.hudFps) lines.add("FPS: " + mc.getCurrentFps() + " / " + mc.options.getMaxFps().getValue());
        if (c.hudPing) {
            var e = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            lines.add("Ping: " + (e == null ? "?" : e.getLatency()) + " ms");
        }
        if (c.hudRam) {
            Runtime rt = Runtime.getRuntime();
            lines.add("RAM: " + (rt.totalMemory() - rt.freeMemory()) / 1048576 + " / " + rt.maxMemory() / 1048576 + " MB");
        }
        if (c.hudCoords) lines.add(String.format("XYZ: %d %d %d  [%s]", mc.player.getBlockX(), mc.player.getBlockY(), mc.player.getBlockZ(),
                mc.player.getHorizontalFacing().asString().substring(0, 1).toUpperCase()));
        if (c.hudTotem) lines.add("Totem: " + Fx.totems + "  (đã nổ " + Fx.pops + ")");
        int y = 26;
        for (String s : lines) {
            int w = mc.textRenderer.getWidth(s);
            ctx.fill(2, y - 2, w + 8, y + 10, 0x90000000);
            ctx.drawText(mc.textRenderer, s, 5, y, col(c, y * 0.01), true);
            y += 13;
        }

        if (c.susOn && !SusChunk.hot.isEmpty()) {          // Chunk Finder: 3 chunk đáng nghi gần nhất
            List<long[]> near = new ArrayList<>();
            for (var en : SusChunk.hot.entrySet()) {
                net.minecraft.util.math.ChunkPos cp = new net.minecraft.util.math.ChunkPos(en.getKey());
                double dx = cp.getCenterX() - mc.player.getX(), dz = cp.getCenterZ() - mc.player.getZ();
                near.add(new long[]{(long) (dx * dx + dz * dz), cp.getCenterX(), cp.getCenterZ(), en.getValue()});
            }
            near.sort(Comparator.comparingLong(a -> a[0]));
            for (int i = 0; i < Math.min(3, near.size()); i++) {
                long[] a = near.get(i);
                String t = "Căn cứ? X " + a[1] + "  Z " + a[2] + "  (" + (int) Math.sqrt(a[0]) + "m, " + a[3] + " block)";
                int w = mc.textRenderer.getWidth(t);
                ctx.fill(2, y - 2, w + 8, y + 10, 0x90000000);
                ctx.drawText(mc.textRenderer, t, 5, y, 0xFFFF5555, true);
                y += 13;
            }
        }

        if (c.hudKeys) {
            int bx = 8, by = H - 74;
            key(ctx, mc, "W", bx + 20, by, 18, 18, mc.options.forwardKey.isPressed());
            key(ctx, mc, "A", bx, by + 20, 18, 18, mc.options.leftKey.isPressed());
            key(ctx, mc, "S", bx + 20, by + 20, 18, 18, mc.options.backKey.isPressed());
            key(ctx, mc, "D", bx + 40, by + 20, 18, 18, mc.options.rightKey.isPressed());
            key(ctx, mc, "LMB " + Fx.cpsL(), bx, by + 40, 29, 14, mc.options.attackKey.isPressed());
            key(ctx, mc, "RMB " + Fx.cpsR(), bx + 29, by + 40, 29, 14, mc.options.useKey.isPressed());
            key(ctx, mc, "SPACE", bx, by + 56, 58, 14, mc.options.jumpKey.isPressed());
        }

        if (c.hudPotion) {
            int py = 90;
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String t = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1) + "  "
                        + (e.isInfinite() ? "∞" : String.format("%d:%02d", e.getDuration() / 1200, (e.getDuration() / 20) % 60));
                int w = mc.textRenderer.getWidth(t);
                ctx.fill(W - w - 10, py - 2, W - 2, py + 10, 0x90000000);
                ctx.drawText(mc.textRenderer, t, W - w - 6, py, col(c, py * 0.01), true);
                py += 13;
            }
        }

        if (c.hudArmor) {
            EquipmentSlot[] sl = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            int ay = H / 2 - 40;
            for (EquipmentSlot s : sl) {
                ItemStack st = mc.player.getEquippedStack(s);
                if (!st.isEmpty()) { ctx.drawItem(st, W - 20, ay); ctx.drawStackOverlay(mc.textRenderer, st, W - 20, ay); }
                ay += 18;
            }
        }

        if (c.crossCustom && mc.options.getPerspective().isFirstPerson()) {
            int sc = Math.max(1, Math.min(6, c.crossScale));
            int cc2 = 0xFF000000 | (c.chroma ? Util.chroma(0.2) : c.crossDrawColor);
            int ox = W / 2 - (CrossPix.N * sc) / 2, oy = H / 2 - (CrossPix.N * sc) / 2;
            for (int yy = 0; yy < CrossPix.N; yy++) for (int xx = 0; xx < CrossPix.N; xx++)
                if (CrossPix.on(c.crossPix, xx, yy)) ctx.fill(ox + xx * sc, oy + yy * sc, ox + (xx + 1) * sc, oy + (yy + 1) * sc, cc2);
        }
        if (c.crossRing) {
            double r = 9 + (Fx.combo > 0 ? 2 : 0) + (System.currentTimeMillis() - Fx.lastHit < 180 ? 4 : 0);
            int cc = col(c, 0.3);
            for (int i = 0; i < 40; i++) {
                double a = i * Math.PI * 2 / 40;
                int px = W / 2 + (int) Math.round(Math.cos(a) * r), py2 = H / 2 + (int) Math.round(Math.sin(a) * r);
                ctx.fill(px, py2, px + 1, py2 + 1, cc);
            }
        }
        if (c.nameTags) nameTags(ctx, mc, c, W, H, tc.getTickDelta(false));
        if (c.hudCombo && Fx.combo > 1) {
            String s = "Combo x" + Fx.combo;
            ctx.drawCenteredTextWithShadow(mc.textRenderer, s, W / 2, H / 2 + 16, col(c, 0));
        }

        if (c.hudArray) {
            List<String> on = new ArrayList<>();
            if (c.espPlayers) on.add("ESP Người"); if (c.espMobs) on.add("ESP Mob"); if (c.espStorage) on.add("ESP Rương");
            if (c.espBlocks) on.add("ESP Block"); if (c.radarOn) on.add("Radar"); if (c.crystal) on.add("Auto Crystal");
            if (c.anchor) on.add("Safe Anchor"); if (c.aimbot) on.add("Aimbot"); if (c.printerOn) on.add("Printer");
            if (c.autoPvp) on.add("Auto PvP"); if (c.mineOn) on.add("Tự đào"); if (c.autoMace) on.add("Elytra Mace");
            if (c.susOn) on.add("Chunk Finder"); if (c.susBase) on.add("Sus ESP"); if (c.spawnerEsp) on.add("Spawner ESP"); if (c.holeEsp) on.add("Hole ESP"); if (c.lightEsp) on.add("Lightfinder"); if (c.trailOn) on.add("Trail"); if (c.shockOn) on.add("Shockwave");
            if (c.velOn) on.add("Velocity"); if (c.trigOn) on.add("Triggerbot"); if (c.hitSelect) on.add("Hit Select");
            if (c.glideOn) on.add("Block Outline"); if (c.placeAnimOn) on.add("Place Anim"); if (c.ringJump) on.add("Jump Circle");
            if (c.ringHit) on.add("Ripple"); if (c.skyOn) on.add("Time"); if (c.chroma) on.add("Chroma");
            on.sort(Comparator.comparingInt((String s) -> -mc.textRenderer.getWidth(s)));
            int ry = 2;
            for (String s : on) {
                int w = mc.textRenderer.getWidth(s);
                ctx.fill(W - w - 8, ry - 1, W - 2, ry + 10, 0x80000000);
                ctx.fill(W - 3, ry - 1, W - 2, ry + 10, col(c, ry * 0.02));
                ctx.drawText(mc.textRenderer, s, W - w - 5, ry + 1, col(c, ry * 0.02), true);
                ry += 11;
            }
        }
    }

    static void nameTags(DrawContext ctx, MinecraftClient mc, Config c, int W, int H, float td) {
        var cam = mc.gameRenderer.getCamera();
        net.minecraft.util.math.Vec3d cp = cam.getPos();
        net.minecraft.util.math.Vec3d f = net.minecraft.util.math.Vec3d.fromPolar(cam.getPitch(), cam.getYaw());
        net.minecraft.util.math.Vec3d right = net.minecraft.util.math.Vec3d.fromPolar(0, cam.getYaw() + 90f);
        net.minecraft.util.math.Vec3d up = net.minecraft.util.math.Vec3d.fromPolar(cam.getPitch() - 90f, cam.getYaw());
        double tanV = Math.tan(Math.toRadians(Math.max(30, mc.options.getFov().getValue()) / 2.0));
        double aspect = (double) W / H;
        for (net.minecraft.entity.player.PlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player || o.isSpectator() || o.squaredDistanceTo(mc.player) > c.espRange * c.espRange) continue;
            net.minecraft.util.math.Vec3d v = o.getLerpedPos(td).add(0, o.getHeight() + 0.95, 0).subtract(cp);
            double z = v.dotProduct(f);
            if (z <= 0.1) continue;
            double sx = W / 2.0 * (1 + v.dotProduct(right) / z / (tanV * aspect));
            double sy = H / 2.0 * (1 - v.dotProduct(up) / z / tanV);
            float hp = o.getHealth() + o.getAbsorptionAmount();
            String s = o.getName().getString() + "  " + String.format("%.0f", hp) + "♥  " + (int) o.distanceTo(mc.player) + "m";
            int w = mc.textRenderer.getWidth(s);
            int bar = (int) (w * Math.min(1f, hp / 20f));
            ctx.fill((int) sx - w / 2 - 3, (int) sy - 3, (int) sx + w / 2 + 3, (int) sy + 11, 0xA0000000);
            ctx.fill((int) sx - w / 2 - 3, (int) sy + 10, (int) sx - w / 2 - 3 + bar + 6, (int) sy + 11, col(c, sy * 0.01));
            ctx.drawText(mc.textRenderer, s, (int) sx - w / 2, (int) sy, 0xFFFFFFFF, true);
        }
    }

    static void key(DrawContext ctx, MinecraftClient mc, String s, int x, int y, int w, int h, boolean on) {
        ctx.fill(x, y, x + w - 1, y + h, on ? 0xB0FF69B4 : 0x90000000);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, s, x + w / 2, y + (h - 8) / 2 + 1, on ? 0xFF000000 : 0xFFFFFFFF);
    }
}
