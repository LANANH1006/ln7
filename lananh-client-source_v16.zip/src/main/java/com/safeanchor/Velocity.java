package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/** Giảm knockback: khi bị đánh, giữ lại chỉ velH% (ngang) và velV% (dọc) lực đẩy. */
public class Velocity {
    static Vec3d prev = Vec3d.ZERO;
    static int last = -100;

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (p == null) return;
        if (c.velOn && c.enabled && p.hurtTime > 0 && p.hurtTime >= p.maxHurtTime - 1 && p.age - last > 5) {
            last = p.age;
            Vec3d cur = p.getVelocity(), kb = cur.subtract(prev);
            p.setVelocity(prev.x + kb.x * c.velH / 100.0, prev.y + kb.y * c.velV / 100.0, prev.z + kb.z * c.velH / 100.0);
        }
        prev = p.getVelocity();
    }
}
